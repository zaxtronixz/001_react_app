'use strict'

module.exports = {
  arrowParens: 'always',
  semi: false,
  singleQuote: true,
  trailingComma: 'all',
}
