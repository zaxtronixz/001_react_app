// NOTE: pleaseUpgradeNode needs to run first!
import './checkEngine.js'

// polyfills
import 'object.fromentries/auto.js'

export { default } from './ServerlessOffline.js'
