export { default } from './catchAllRoute.js'
