export { default } from './WebSocket.js'
