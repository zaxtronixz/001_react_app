import cuid from 'cuid'

export default function createUniqueId() {
  return cuid()
}
