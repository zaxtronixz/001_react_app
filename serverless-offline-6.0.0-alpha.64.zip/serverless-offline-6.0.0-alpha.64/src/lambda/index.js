export { default } from './Lambda.js'
