# Manual test Ruby

## Installation

In the plugin directory:
`npm link`
`cd manual_test_ruby`
`npm link serverless-offline`
