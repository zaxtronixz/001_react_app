'use strict'

exports.uncategorizedHandler1 = async () => {
  return {
    foo: 'bar',
  }
}

exports.uncategorizedHandler2 = async () => {
  return {
    foo: 'bar',
  }
}
