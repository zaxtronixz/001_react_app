function hello () {
  RESPONSE="{\"body\": \"{\\\"message\\\": \\\"Hello Provided!\\\"}\", \"statusCode\": 200}"

  echo $RESPONSE
}
