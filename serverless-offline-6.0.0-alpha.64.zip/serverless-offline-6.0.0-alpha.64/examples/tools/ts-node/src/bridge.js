'use strict'

require('ts-node').register()
module.exports = require('./handler.ts')
