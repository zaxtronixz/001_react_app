'use strict'

require('@babel/register')
module.exports = require('./handler.js')
